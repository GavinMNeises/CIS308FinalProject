#include <gb/gb.h>

int var_0;  /* In external RAM bank 0 */
