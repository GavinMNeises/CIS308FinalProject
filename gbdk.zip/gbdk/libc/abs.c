#include <stdlib.h>

int abs(int num)
{
  if(num < 0)
    return -num;
  else
    return num;
}
